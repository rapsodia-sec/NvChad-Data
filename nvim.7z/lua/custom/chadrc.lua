---@type ChadrcConfig 
 local M = {}
 M.ui = {theme = 'onedark'}
 return M